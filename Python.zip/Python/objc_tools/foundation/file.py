from objc_util import ObjCClass

NSFileManager = ObjCClass('NSFileManager')
manager = NSFileManager.defaultManager()
