__doc__ = '''This library is for modules that will only work on iOS 10'''
