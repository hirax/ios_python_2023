# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

from ctypes import *
from rubicon.objc import ObjCClass
from rubicon.objc.runtime import *
from rubicon.objc.types import *

import ctypes
from ctypes import Structure, sizeof, byref, cdll, pydll, c_void_p, c_char, c_byte, c_char_p, c_double, c_float, c_int, c_longlong, c_short, c_bool, c_long, c_int32, c_ubyte, c_uint, c_ushort, c_ulong, c_ulonglong, POINTER, pointer, c_int64, c_int32, c_uint32

from enum import Enum

#=============== Load Frameworks ==============
# http://web.archive.org/web/20210423080647/https://iphonedev.wiki/index.php/Frameworks
# Public: https://iphonedev.wiki/index.php/Frameworks
# Private: https://iphonedev.wiki/index.php/PrivateFrameworks

CoreLocation = cdll.LoadLibrary(
  "/System/Library/Frameworks/CoreLocation.framework/CoreLocation"
)
CoreMotion = cdll.LoadLibrary(
  "/System/Library/Frameworks/CoreMotion.framework/CoreMotion"
)
AVFoundation = cdll.LoadLibrary(
  "/System/Library/Frameworks/AVFoundation.framework/AVFoundation"
)
AudioToolbox = cdll.LoadLibrary(
  "/System/Library/Frameworks/AudioToolbox.framework/AudioToolbox"
)

# =========== Enum ===========================================

# https://developer.limneos.net/index.php
# https://github.com/mmmulani/class-dump-o-tron
# https://gist.github.com/githubutilities/dfa762a11e1064bfce5f
# https://code.google.com/archive/p/undocumented-goodness/source/default/source

# =========== Enum ===========================================

#https://pub.dev/documentation/flutter_amap_location_plugin/latest/amap_location_option/CLLocationAccuracy.html
class CLLocationAccuracy(Enum):
    kCLLocationAccuracyBest = 0
    kCLLocationAccuracyNearestTenMeters = 1
    kCLLocationAccuracyHundredMeters = 2
    kCLLocationAccuracyKilometer = 3
    kCLLocationAccuracyThreeKilometers = 4

#https://docs.microsoft.com/ja-jp/dotnet/api/corelocation.cldeviceorientation?view=xamarin-ios-sdk-12
class CLDeviceOrientation(Enum):
    FaceDown = 6 # parallel to the ground and the face is pointing towards the ground.
    FaceUp = 5 # parallel to the ground and the face is pointing towards the sky.
    LandscapeLeft = 3 # in an upright position, with the home button to the right.
    LandscapeRight = 4 # in an upright position, with the home button to the left.
    Portrait = 1 # in an upright position, with the home button towards the ground.
    PortraitUpsideDown = 2 # in an upright position, with the home button towards the sky.
    Unknown = 0 # The device's orientation is unavailable.

#https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avaudioquality?view=xamarin-ios-sdk-12
class AVAudioQuality(Enum):
    AVAudioQualityMin = 0
    AVAudioQualityLow = 32
    AVAudioQualityMedium = 64
    AVAudioQualityHigh = 96
    AVAudioQualityMax = 127

class AVFormatIDKey(Enum):  #UInt32
    kAudioFormatLinearPCM      = 1819304813
    kAudioFormatAppleIMA4      = 1768775988
    kAudioFormatMPEG4AAC       = 1633772320
    kAudioFormatMACE3          = 1296122675
    kAudioFormatMACE6          = 1296122678
    kAudioFormatULaw           = 1970037111
    kAudioFormatALaw           = 1634492791
    kAudioFormatMPEGLayer1     = 778924081
    kAudioFormatMPEGLayer2     = 778924082
    kAudioFormatMPEGLayer3     = 778924083
    kAudioFormatAppleLossless  = 1634492771

# https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcapturedeviceposition?view=xamarin-mac-sdk-14
class AVCaptureDevicePosition(Enum):
    Unspecified = 0
    Back = 1
    Front = 2

# https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcaptureflashmode?view=xamarin-mac-sdk-14
class AVCaptureFlashMode(Enum):
    Off = 0  # Never use the flash.
    On = 1   # Always use the flash.
    Auto = 2 # Automatic.

#https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcapturevideoorientation?view=xamarin-mac-sdk-14
class AVCaptureVideoOrientation(Enum):
    Portrait = 1 # Portrait
    PortraitUpsideDown = 2 # Portrait, upside down.
    LandscapeRight = 3 # Landscape, turned right.
    LandscapeLeft = 4 # Landscape, turned left.

#https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcapturefocusmode?view=xamarin-mac-sdk-14
class AVCaptureFocusMode(Enum):
    Locked = 0 #Focus that will not change automatically.
    AutoFocus = 1 # Normal autofocus.
    ContinuousAutoFocus = 2 # Autofocus that attempts to track the subject.

#https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcapturefocusmode?view=xamarin-mac-sdk-14
class AVCaptureFocusMode(Enum):
    Locked = 0 # Focus that will not change automatically.
    AutoFocus = 1 # Normal autofocus.
    ContinuousAutoFocus = 2 # Autofocus that attempts to track the subject.

#https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcaptureexposuremode?view=xamarin-mac-sdk-14
class AVCaptureExposureMode(Enum):
    Locked = 0 # Exposure setting is locked.
    AutoExpose = 1 # The camera performs auto expose.
    ContinuousAutoExposure = 2 # Performs auto-expose and adjusts the setting continously.
    Custom = 3 # Exposure is limited by the ISO and ExposureDuration properties.

#https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcapturewhitebalancemode?view=xamarin-mac-sdk-14
class AVCaptureWhiteBalanceMode(Enum):
    Locked = 0 # Auto white balance has been locked.
    AutoWhiteBalance = 1 # Automatic white balance, set it once.
    ContinuousAutoWhiteBalance = 2 # Contimuously evaluate and set the white balance.

#https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcapturetorchmode?view=xamarin-mac-sdk-14
class AVCaptureTorchMode(Enum):
    Off = 0 # Never uses the torch.
    On = 1 # Always uses the torch.
    Auto = 2 # Uses the torch based on the available light measured.

#　https://github.com/MaddTheSane/SwiftMacTypes/blob/master/SwiftAudioAdditions/AudioFileExt.swift
# AudioFileType

class CMMagneticField(Structure):
    Uncalibrated = -1 # Magnetic calibration has not occurred.
    Low = 0 # The magnetic calibration was marginal.
    Medium = 1 # The magnetic calibration was of medium quality.
    High = 2 # The magnetic calibration was of high quality.

#========== Constants ================

# https://github.com/xybp888/iOS-SDKs/blob/master/iPhoneOS13.0.sdk/System/Library/Frameworks/AVFoundation.framework/Headers/AVCaptureDevice.h
# AVCaptureDevice.h
# typedef NSString *AVCaptureDeviceType NS_STRING_ENUM
AVCaptureDeviceTypeExternalUnknown = 'AVCaptureDeviceTypeExternalUnknown'
AVCaptureDeviceTypeBuiltInMicrophone = 'AVCaptureDeviceTypeBuiltInMicrophone'
AVCaptureDeviceTypeBuiltInWideAngleCamera = 'AVCaptureDeviceTypeBuiltInWideAngleCamera'
AVCaptureDeviceTypeBuiltInTelephotoCamera = 'AVCaptureDeviceTypeBuiltInTelephotoCamera'
AVCaptureDeviceTypeBuiltInUltraWideCamera = 'AVCaptureDeviceTypeBuiltInUltraWideCamera'
AVCaptureDeviceTypeBuiltInDualCamera = 'AVCaptureDeviceTypeBuiltInDualCamera'
AVCaptureDeviceTypeBuiltInDualWideCamera = 'AVCaptureDeviceTypeBuiltInDualWideCamera'
AVCaptureDeviceTypeBuiltInTripleCamera = 'AVCaptureDeviceTypeBuiltInTripleCamera'
AVCaptureDeviceTypeBuiltInTrueDepthCamera = 'AVCaptureDeviceTypeBuiltInTrueDepthCamera'
AVCaptureDeviceTypeBuiltInDuoCamera = 'AVCaptureDeviceTypeBuiltInDuoCamera'
# https://developer.apple.com/documentation/avfoundation/avcapturedevicetypebuiltinlidardepthcamera?changes=latest_minor&language=objc
AVCaptureDeviceTypeBuiltInLiDARDepthCamera = 'AVCaptureDeviceTypeBuiltInLiDARDepthCamera'

# https://docs.microsoft.com/ja-jp/dotnet/api/avfoundation.avcapturedevicetype?view=xamarin-ios-sdk-12
BuiltInMicrophone  =  0
BuiltInTelephotoCamera  =  2
#BuiltInDuoCamera  =  3
BuiltInDualCamera  =  4
BuiltInTrueDepthCamera  =  5

# https://github.com/xybp888/iOS-SDKs/blob/master/iPhoneOS13.0.sdk/System/Library/Frameworks/AVFoundation.framework/Headers/AVMediaFormat.h
# AVMediaFormat.h
# typedef NSString * AVMediaType NS_EXTENSIBLE_STRING_ENUM;
# 下記多分間違ってる
AVMediaTypeVideo = 0
AVMediaTypeAudio = 1
AVMediaTypeText = 2
AVMediaTypeClosedCaption = 3
AVMediaTypeSubtitle = 4
AVMediaTypeTimecode = 5
AVMediaTypeMetadata = 6
AVMediaTypeMuxed = 7

# https://docs.microsoft.com/en-us/dotnet/api/avfoundation.avmediatype.video?view=xamarin-ios-sdk-12
# https://forum.omz-software.com/topic/3555/casting-nsarray-from-objcinstancemethodproxy/4
AVMediaTypeVideo = 'vide'

# definitions
# https://github.com/xybp888/iOS-SDKs/blob/master/iPhoneOS13.6.sdk/System/Library/Frameworks/AVFoundation.framework/Headers/AVCaptureDevice.h


# PixelBuffer Definitions
c = cdll.LoadLibrary(None)
CVPixelBufferLockBaseAddress = c.CVPixelBufferLockBaseAddress
CVPixelBufferLockBaseAddress.argtypes = [c_void_p, c_int]
CVPixelBufferLockBaseAddress.restype = None

CVPixelBufferUnlockBaseAddress = c.CVPixelBufferUnlockBaseAddress
CVPixelBufferUnlockBaseAddress.argtypes = [c_void_p, c_int]
CVPixelBufferUnlockBaseAddress.restype = None

CVPixelBufferGetWidthOfPlane = c.CVPixelBufferGetWidthOfPlane
CVPixelBufferGetWidthOfPlane.argtypes = [c_void_p, c_int]
CVPixelBufferGetWidthOfPlane.restype = c_int

CVPixelBufferGetHeightOfPlane = c.CVPixelBufferGetHeightOfPlane
CVPixelBufferGetHeightOfPlane.argtypes = [c_void_p, c_int]
CVPixelBufferGetHeightOfPlane.restype = c_int

CVPixelBufferGetBaseAddressOfPlane = c.CVPixelBufferGetBaseAddressOfPlane
CVPixelBufferGetBaseAddressOfPlane.argtypes = [c_void_p, c_int]
CVPixelBufferGetBaseAddressOfPlane.restype = c_void_p

CVPixelBufferGetBytesPerRowOfPlane = c.CVPixelBufferGetBytesPerRowOfPlane
CVPixelBufferGetBytesPerRowOfPlane.argtypes = [c_void_p, c_int]
CVPixelBufferGetBytesPerRowOfPlane.restype = c_int

#=============== Structure definitions =========
# to asign appropriate "type" of Structure for "message"
def member(obj, message, type):
    return send_message(obj,message, restype=type, argtypes=[])

#class CMAltitudeData(Structure): # CMLogItem
#    _fields_ = [ ('timestamp', c_double),        # timestamp
#                 ('relativeAltitude', c_double), # m
#                 ('pressure', c_double) ]        # k pascal

class CMAcceleration(Structure):
    _fields_ = [ ('x', c_double),   # m/s^2.
                 ('y', c_double),   # m/s^2.
                 ('z', c_double) ]  # m/s^2.

class CMRotationRate(Structure):
    _fields_ = [ ('x', c_double),   # ratio.
                 ('y', c_double),   # ratio.
                 ('z', c_double) ]  # ratio.

class CMAcceleration(Structure):
    _fields_ = [ ('x', c_double),   # m/s^2.
                 ('y', c_double),   # m/s^2.
                 ('z', c_double) ]  # m/s^2.

class CMMagneticField(Structure):
    _fields_ = [ ('x', c_double),   # microtesla
                 ('y', c_double),   # microtesla
                 ('z', c_double) ]  # microtesla

class CMMagneticField(Structure):
    _fields_ = [ ('field', CMMagneticField),
                 ('accuracy', c_int)]  # CMMagneticFieldCalibrationAccuracy

# ..........................
class AVCaptureWhiteBalanceTemperatureAndTintValues(Structure):
    _fields_=[('temperature',  ctypes.c_float),  # values must be between 1.0 and maxWhiteBalanceGain
              ('tint', ctypes.c_float)]
    def __init__(self,temperature=6000.0,tint=0.0):
        self.temperature=temperature
        self.tint = tint

# ..........................
class CAVCaptureWhiteBalanceGain(Structure):
    _fields_=[('blueGain',  ctypes.c_float),  # values must be between 1.0 and maxWhiteBalanceGain
              ('greenGain', ctypes.c_float),
              ('redGains',  ctypes.c_float)]
    def __init__(self,blueGain=1.0,greenGain=1.0,redGain=1.0):
        self.blueGain=blueGain
        self.greenGain=greenGain
        self.redGain=redGain


# 型定義
CMTimeValue = c_int64
CMTimeScale = c_int32
CMTimeFlags = c_uint32
CMTimeEpoch = c_int64

class CMTime(Structure):
    _fields_=[('value', CMTimeValue),
              ('timescale', CMTimeScale),
              ('flags',CMTimeFlags),
              ('epoch',CMTimeEpoch)]
    def __init__(self, value=0, timescale=1, flags=0, epoch=0):
        self.value=value
        self.timescale=timescale
        self.flags=flags
        self.epoch=epoch

# メインプログラムのシンボル→プログラム起動時にロードされた全共有オブジェクト→
# dlopen()のRTLD_GLOBALのフラグでロードされたすべての共有オブジェクトを検索
c = cdll.LoadLibrary(None)

# Function(CMTimeMakeWithSeconds, CMTimeGetSeconds etc.)について、引数・返値を設定する
c.CMTimeMakeWithSeconds.argtypes = [ctypes.c_double, ctypes.c_int32]
c.CMTimeMakeWithSeconds.restype = CMTime
c.CMTimeGetSeconds.argtypes = [CMTime]
c.CMTimeGetSeconds.restype = c_double


#=============== Load Classes ==============

# definitionは
# from rubicon.objc.runtime import Foundation
# hoge = objc_const( Foundation, "hoge")
# も使いやすそう

# definitions
# https://cnbin.github.io/blog/2015/11/03/avcapturedevice-de-ji-ge-shu-xing/


NSOperationQueue = ObjCClass('NSOperationQueue')

CMMotionManager = ObjCClass('CMMotionManager')
CMDeviceMotion = ObjCClass('CMDeviceMotion')
CMAccelerometerData = ObjCClass('CMAccelerometerData')

CMAltimeter = ObjCClass('CMAltimeter')
CMAttitude = ObjCClass('CMAttitude')
# timestamp: NSTimeInterval: デバイス起動からの秒
# relativeAltitude: NSTimeInterval: 相対標高(m)
# pressure: NSNumber: 気圧(kパスカル)

AVCaptureSession = ObjCClass('AVCaptureSession')
AVCaptureConnection = ObjCClass('AVCaptureConnection')
AVCaptureDevice = ObjCClass('AVCaptureDevice')
AVCaptureDeviceInput = ObjCClass('AVCaptureDeviceInput')
AVCapturePhotoOutput = ObjCClass('AVCapturePhotoOutput')
AVCaptureVideoPreviewLayer = ObjCClass('AVCaptureVideoPreviewLayer')
AVCapturePhotoSettings = ObjCClass('AVCapturePhotoSettings')
AVCaptureDeviceDiscoverySession = ObjCClass('AVCaptureDeviceDiscoverySession')




