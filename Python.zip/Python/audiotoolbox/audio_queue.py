from classes.header import *
import rubicon_objc
import ctypes

def init():
    AudioQueueNewInput(
        &audioFormat,
        MyAudioQueueInputCallback,
        self,
        NULL,
        NULL,
        0,
        &__audioQueueObject)
        
def start():
    AudioQueueStart(self.audioQueueObject, NULL)

def stop():
    AudioQueueStop(self.audioQueueObject, YES)
    AudioQueueDispose(self.audioQueueObject, YES)
    self.audioQueueObject = NULL
