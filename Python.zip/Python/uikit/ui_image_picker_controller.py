# coding: utf-8
# Copyright (c) 2018 Jun Hirabayashi (jun@hirax.net)
# Released under the MIT license
# https://opensource.org/licenses/mit-license.php

from objc_util import *
from classes.header import *

#UIImagePickerController = rubicon_objc.api.ObjCClass('UIImagePickerController')
UIImagePickerController = ObjCClass('UIImagePickerController')
if IImagePickerController.isSourceTypeAvailable_( UIImagePickerControllerSourceType.Camera ):
    print("camera is available.")
else:
    return

IImagePickerController_ = IImagePickerController.alloc().init()

def locationManager_didFinishPickingMediaWithInfo_( _self, _cmd, _manager, _locations):
        print("called.")

# delegateを作成する
LocationManagerDelegate = create_objc_class(
    'LocationManagerDelegate',                      # 作成する delegate クラスの名称
    methods = [locationManager_didUpdateLocations_], # delegate method
    protocols=['CLLocationManagerDelegate']) # プロトコル指定
CLLocationManagerDelegate_ = LocationManagerDelegate.new()
retain_global(CLLocationManagerDelegate_)
CLLocationManager_.delegate = CLLocationManagerDelegate_


IImagePickerController_.sourceType = UIImagePickerControllerSourceType.Camera
IImagePickerController_.delegate = self  # ???
IImagePickerController_.allowsEditing = True

if __name__ == '__main__':
    import time
    for i in range(10):
        print( main_screen.brightness )
        time.sleep(1)


