# https://forum.omz-software.com/topic/3896/objc_tools-library/4

from objc_util import ObjCClass, ObjCBlock, c_void_p, ObjCInstance,ns

CMMotionActivityManager = ObjCClass('CMMotionActivityManager')
CMMotionActivityManager_ = CMMotionActivityManager.alloc().init()
NSOperationQueue = ObjCClass('NSOperationQueue')
NSDate = ObjCClass('NSDate')

# アクティビティを格納するリストを作っておく
motionActivityData = []

# アクティビティを得るためのハンドラーを書く
def getData(_cmd, _activityData, error):
    global motionActivityData
    # CMMotionActivity
    activityData = ObjCInstance(_activityData)
    if not error == None:
        err = ObjCInstance(error)
        print('error:'+str(err))
    else:
        #s = str(activityData).split(',')
        s = str(activityData).replace('>',',').split(',')
        motionActivityData.append({
        'confidence':s[4],
        'stationary':s[8],
        'walking':s[10],
        'running':s[12],
        'automotive':s[14],
        'cycling':s[16],
        'unknown':s[6]
        })
# ハンドラーを登録する
activity_block = ObjCBlock(
        getData,
        restype=None,
        argtypes=[c_void_p, c_void_p, c_void_p])

def queryActivityFromDatetoDate(fromDate,toDate):
    if CMMotionActivityManager.isActivityAvailable():
        # アクティビティを調べる
        CMMotionActivityManager_.queryActivityStartingFromDate_toDate_toQueue_withHandler_(
            ns(fromDate),
            ns(toDate),
            NSOperationQueue.mainQueue(),
            activity_block)
    else:
        print('Unavailable')

